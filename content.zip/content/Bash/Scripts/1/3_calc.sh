#!/bin/bash
# calc.sh
# Простой арифметический калькулятор
echo "Введите первое число:"
read num1
echo "Введите второе число:"
read num2

echo "Сумма: $(($num1 + $num2))"
echo "Разность: $(($num1 - $num2))"
echo "Произведение: $(($num1 * $num2))"
echo "Частное: $(($num1 / $num2))"